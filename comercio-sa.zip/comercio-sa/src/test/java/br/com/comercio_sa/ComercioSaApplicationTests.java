package br.com.comercio_sa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComercioSaApplicationTests {

	@Test
	void contextLoads() {
	}

}
