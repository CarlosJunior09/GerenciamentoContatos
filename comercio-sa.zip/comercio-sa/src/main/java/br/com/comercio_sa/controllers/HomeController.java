package br.com.comercio_sa.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import br.com.comercio_sa.model.Cliente;

@Controller
public class HomeController {
	
	@GetMapping("/index")
	public ModelAndView index() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("home/index");
		mv.addObject("cliente", new Cliente());
		return mv;
		
	}

}
