package br.com.comercio_sa.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import br.com.comercio_sa.dao.ClienteDao;
import br.com.comercio_sa.model.Cliente;

@Controller
public class ClienteController {
	
	@Autowired
	private ClienteDao clienterepositorio;

	@GetMapping("/inserirClientes")
	public ModelAndView InsertClientes(Cliente cliente) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Cliente/formCliente");
		mv.addObject("cliente", new Cliente());
		return mv;
	}
	
	@PostMapping("/InsertClientes")
	public ModelAndView inserirCliente(Cliente cliente) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("redirect:/clientes-adicionados");
		clienterepositorio.save(cliente);
		return mv;
	}
	
	@GetMapping("clientes-adicionados")
	public ModelAndView listagemClientes() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Cliente/listClientes");
		mv.addObject("clientesList", clienterepositorio.findAll());
		return mv;
	}
	
	@GetMapping("/alterar/{id}")
	public ModelAndView alterar(@PathVariable("id") Integer id) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Cliente/alterar");
		Cliente cliente = clienterepositorio.getOne(id);
		mv.addObject("cliente", cliente);
		return mv;
	}
	
	@PostMapping("/alterar")
	public ModelAndView alterar(Cliente cliente) {
		ModelAndView mv = new ModelAndView();
		clienterepositorio.save(cliente);
		mv.setViewName("redirect:/clientes-adicionados");
		return mv;
	}
	
	@GetMapping("/excluir/{id}")
	public String excluirCliente(@PathVariable("id") Integer id) {
		clienterepositorio.deleteById(id);
		return "redirect:/clientes-adicionados";
	}
	
	@PostMapping("pesquisar-cliente")
	public ModelAndView pesquisarCliente(@RequestParam(required = false) String termo) {
	    ModelAndView mv = new ModelAndView();
	    List<Cliente> listaClientes;

	    if (termo == null || termo.trim().isEmpty()) {
	        listaClientes = clienterepositorio.findAll();
	    } else {
	        listaClientes = clienterepositorio.buscarPorNomeOuCpf(termo);
	    }

	    mv.addObject("ListaDeClientes", listaClientes);
	    mv.setViewName("Cliente/pesquisa-resultado");
	    return mv;
	}

	
}
